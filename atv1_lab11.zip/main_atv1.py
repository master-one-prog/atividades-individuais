from atv1 import Entrega_terrestre, Entrega_aerea
import os

entregas = []
while True:
    print("--------BEM-VINDO A TRANSPORTADORA MACHADO----------")
    print("1 - Criar nova entrega")
    print("2 - listar entregas")
    op = int(input("Escolha uma opção: "))
    if op == 1:
        endereco_destino = input("informe o endereço: ")  
        status = 'em separação'
        peso = float(input("informe o peso: "))
        tipo_entrega = int(input("Qual seria a entrega? (1 - Terrestre/  2 - Aérea)"))

        if tipo_entrega == 1:
            distancia_km = float(input("informe a distancia em km: "))
            
            entrega = Entrega_terrestre(endereco_destino, status, peso, distancia_km)
            
            entregas.append(entrega)
            print("Entrega terrestre criada com sucesso!")

        elif tipo_entrega == 2:
            taxa_despacho = float(input("informe a tacha de despacho: ")) 
            
            entrega = Entrega_aerea(endereco_destino, status, peso, taxa_despacho)

            entregas.append(entrega)
            print("Entrega aerea criada com sucesso!")
        else:
            print("INVÁLIDO")

    elif op == 2:
        if len(entregas) == 0:
            print("Não existem entregas cadastradas.")

        else:
            for entrega in entregas:
                entrega.imprimir_dados()

    else:
        print("Opção inválida.")

    d = input("deseja contnuar: (s/n)")
    os.system('cls')
    if d == 'n':
        break  