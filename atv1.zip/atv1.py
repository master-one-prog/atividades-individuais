from abc import ABC, abstractmethod

class Entrega(ABC):
    def __init__(self, endereco_destino, status, peso):
        self.endereco = endereco_destino
        self.status = status
        self.peso = peso

    def atualizar_status(self, novo_status):
        self.status = novo_status

    def imprimir_dados(self):
        print(self.endereco)
        print(self.status)
        print(self.peso)
        
    @abstractmethod
    def calcular_frete(self):
        pass

class Entrega_terrestre(Entrega):
    def __init__(self, endereco_destino, status, peso, distancia_km):
        super().__init__(endereco_destino, status, peso)
        
        self.distancia = distancia_km

    def calcular_frete(self):
        if self.distancia <= 100:
            frete = 20
        elif self.distancia > 100 and self.distancia <= 500:
            frete = 40 + 1.5 * self.peso

        else:
            frete = 70 + 2.2 * self.peso

        return frete
    
    def imprimir_dados(self):
        super().imprimir_dados()
        print(self.distancia)
        print(self.calcular_frete())


class Entrega_aerea(Entrega):
    def __init__(self, endereco_destino, status, peso, taxa_despacho):
        super().__init__(endereco_destino, status, peso)

        self.taxa = taxa_despacho

    def calcular_frete(self):
        frete = self.taxa + 12 * self.peso
        return frete
    def imprimir_dados(self):
        super().imprimir_dados()
        print(self.taxa)
        print(self.calcular_frete())
        