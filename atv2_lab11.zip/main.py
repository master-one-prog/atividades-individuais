from meio_pagamento import Meio_de_pagamento, Pix, Boleto, Cartao_de_Credito
import os

cartao = Cartao_de_Credito(None, 3321_2112_2222_9270)
pix = Pix(None, 31996220936) #pix verdadeiro em, quiser mandar
boleto = Boleto(None, '///==--_/' )

while True:
    print("-----PAGAMENTO-------")
    print("1- Cartão de Crédito ")
    print("2- Pix")
    print("3- Boleto")

    op = int(input("Qual a forma de pagamento: "))

    print("1- Processar pagamento ")
    print("2- Cancelar pagamento")
    print("3- Gerar comprovante")

    met = int(input("Qual operação deseja realizar? "))

    if op == 1:
       
        if met == 1:
            cartao.processar_pagamento()

        elif met == 2:
            cartao.cancelar_pagamento()

        elif met == 3:
            cartao.gerar_comprovante()

    elif op == 2:
           
            if met == 1:
                pix.processar_pagamento()
    
            elif met == 2:
                pix.cancelar_pagamento()
    
            elif met == 3:
                pix.gerar_comprovante()

    elif op == 3:
            
            if met == 1:
                boleto.processar_pagamento()
    
            elif met == 2:
                boleto.cancelar_pagamento()
    
            elif met == 3:
                boleto.gerar_comprovante()

    else: 
         print("ERRO")

    d = input("deseja contnuar: (s/n)")
    os.system('cls')
    if d == 'n':
         break  


