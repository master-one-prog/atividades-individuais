from abc import ABC, abstractmethod

class Meio_de_pagamento(ABC):
    def __init__(self, status):
        self.status = status
    
    @abstractmethod
    def processar_pagamento(self):
        pass
    
    
    @abstractmethod
    def cancelar_pagamento(self):
        pass

    @abstractmethod
    def gerar_comprovante(self):
        pass

class Cartao_de_Credito(Meio_de_pagamento):
    def __init__(self, status, numero_cartao):
        super().__init__(status)

        self.numero_cartao = numero_cartao

    def processar_pagamento(self):
        self.status = 'Aprovado'
        print("Pagamento Processado!")

    def cancelar_pagamento(self):
        self.status = 'cancelado'
        print("Pagamento cancelado!")
    
    def gerar_comprovante(self):
        if self.status == 'Aprovado':
            print("Comprovante gerado para o cartão final:", str(self.numero_cartao)[-4:])
        else:
            print("PAGAMENTO CANCELADO")


class Pix(Meio_de_pagamento):
    def __init__(self, status, chave_pix):
        super().__init__(status)

        self.chave = chave_pix

    def processar_pagamento(self):
        self.status = 'Aprovado'
        print("Aguardando pagamento para a seguinte chave Pix: ", self.chave)

    def cancelar_pagamento(self):
            print("OPERAÇÃO NÃO PODE SER CANCELADA")

    def gerar_comprovante(self):
            print("Comprovante gerado!")

class Boleto(Meio_de_pagamento):
    def __init__(self, status, codigo_de_barra):
        super().__init__(status)

        self.cod = codigo_de_barra

    def processar_pagamento(self):
        self.status = 'Aprovado'
        print("Aguardando pagamento para o codigo de barras: ", self.cod)

    def cancelar_pagamento(self):
            self.status = 'cancelado'
            print("Boleto cancelado!")

    def gerar_comprovante(self):
            if self.status == 'Aprovado':
                print("Comprovante gerado!!") 
            else:
                print("PAGAMENTO CANCELADO")