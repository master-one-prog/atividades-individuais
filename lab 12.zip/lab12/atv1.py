lista = [0,1,2,3,4,5,6,7,8,9,10]
try:
    i = int(input("Escolha um indice de 0 a 10: "))
    print(f"indice {lista[i]}")

except IndexError:
    print("Valor inválido ")