# soma valores 
try:
    a = float(input("INFORME UM VALOR: ")) 
    b = float(input("INFORME OUTRO VALOR: ")) 

    c = a + b
    print(c)

except TypeError:
    print("Os tipos são incompatíveis.")