def somar_valores(a, b):
    try:
        print(f"soma = {a + b}")
    except TypeError:
        return "Erro: os tipos dos valores são incompatíveis."

print (somar_valores(2, 5))
print(somar_valores("Olá", 10))