
try:
    numero = int(input("informe um valor INTEIRO: "))
    divisor = int(input("informe um divisor "))

    numero /= 10
    numero /= divisor 

    print(numero)
except ValueError:
    print("VALOR INVALIDO")

except ZeroDivisionError:
    print("NÃO E POSSIVEL DIVIDIR POR 0")