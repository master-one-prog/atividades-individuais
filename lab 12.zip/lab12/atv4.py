def verifica_idade(idade):
    if idade < 0: raise ValueError("Então vc não não nasceu?")

    elif idade < 18: raise ValueError("AINDA E BEBEZIINHOO")

    else:
        print("Parabéns, você ja pode dirigir") 

idade = int(input("Quantos anos vc tem?"))
print(verifica_idade(idade))

